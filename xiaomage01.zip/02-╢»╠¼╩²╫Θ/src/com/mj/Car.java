package com.mj;

public class Car {

}
