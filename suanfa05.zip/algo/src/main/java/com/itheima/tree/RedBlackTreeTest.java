package com.itheima.tree;

import org.junit.Test;

import java.util.TreeMap;

/**
 * 红黑树测试
 */
public class RedBlackTreeTest {
    
    @Test
    public void test1(){
        TreeMap treeMap = new TreeMap();
        treeMap.put("itcast","good");
        treeMap.put("itheima","very good");
    }
}
