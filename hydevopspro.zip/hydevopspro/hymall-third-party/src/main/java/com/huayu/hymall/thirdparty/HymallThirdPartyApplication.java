package com.huayu.hymall.thirdparty;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HymallThirdPartyApplication {

	public static void main(String[] args) {
		SpringApplication.run(HymallThirdPartyApplication.class, args);
	}

}
