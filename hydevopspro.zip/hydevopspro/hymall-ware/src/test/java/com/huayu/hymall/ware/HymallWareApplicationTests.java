package com.huayu.hymall.ware;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HymallWareApplicationTests {

	@Test
	void contextLoads() {
	}

}
