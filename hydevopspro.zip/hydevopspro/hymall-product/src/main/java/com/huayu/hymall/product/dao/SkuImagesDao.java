package com.huayu.hymall.product.dao;

import com.huayu.hymall.product.entity.SkuImagesEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * sku图片
 * 
 * @author yuanbao
 * @email 2270830140@qq.com
 * @date 2020-12-16 20:48:54
 */
@Mapper
public interface SkuImagesDao extends BaseMapper<SkuImagesEntity> {
	
}
