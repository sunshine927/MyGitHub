package com.huayu.hymall.product;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

@MapperScan("com.huayu.hymall.product.dao")
@EnableDiscoveryClient
@SpringBootApplication
public class HymallProductApplication {

	public static void main(String[] args) {
		SpringApplication.run(HymallProductApplication.class, args);
	}

}
