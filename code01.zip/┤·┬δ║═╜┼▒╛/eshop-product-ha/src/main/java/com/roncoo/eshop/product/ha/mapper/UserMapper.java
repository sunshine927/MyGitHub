package com.roncoo.eshop.product.ha.mapper;

public interface UserMapper {

}
