package com.huayu.hymall.ware.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.huayu.common.utils.PageUtils;
import com.huayu.hymall.ware.entity.WareInfoEntity;

import java.util.Map;

/**
 * 仓库信息
 *
 * @author yuanbao
 * @email 2270830140@qq.com
 * @date 2020-12-16 22:01:40
 */
public interface WareInfoService extends IService<WareInfoEntity> {

    PageUtils queryPage(Map<String, Object> params);
}

