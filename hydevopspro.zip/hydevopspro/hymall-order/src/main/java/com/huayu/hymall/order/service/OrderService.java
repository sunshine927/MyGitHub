package com.huayu.hymall.order.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.huayu.common.utils.PageUtils;
import com.huayu.hymall.order.entity.OrderEntity;

import java.util.Map;

/**
 * 订单
 *
 * @author yuanbao
 * @email 2270830140@qq.com
 * @date 2020-12-16 21:50:12
 */
public interface OrderService extends IService<OrderEntity> {

    PageUtils queryPage(Map<String, Object> params);
}

