package com.huayu.hymall.coupon.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.huayu.common.utils.PageUtils;
import com.huayu.hymall.coupon.entity.SkuFullReductionEntity;

import java.util.Map;

/**
 * 商品满减信息
 *
 * @author yuanbao
 * @email 2270830140@qq.com
 * @date 2020-12-16 21:02:01
 */
public interface SkuFullReductionService extends IService<SkuFullReductionEntity> {

    PageUtils queryPage(Map<String, Object> params);
}

