package com.huayu.hymall.gateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HymallGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
