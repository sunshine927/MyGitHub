package com.huayu.common.valid;

public interface UpdateStatusGroup {
}
