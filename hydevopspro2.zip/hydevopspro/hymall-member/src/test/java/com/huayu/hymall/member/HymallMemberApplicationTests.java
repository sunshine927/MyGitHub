package com.huayu.hymall.member;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HymallMemberApplicationTests {

	@Test
	void contextLoads() {
	}

}
