package com.roncoo.eshop.storm.bolt;

public class Test {
	
	public static void main(String[] args) {
		double cnt = 7 * 0.95;
		System.out.println(cnt);
		System.out.println((int)Math.floor(cnt));       
	}
	
}
