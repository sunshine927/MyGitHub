package com.huayu.hymall.coupon.dao;

import com.huayu.hymall.coupon.entity.SpuBoundsEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * 商品spu积分设置
 * 
 * @author yuanbao
 * @email 2270830140@qq.com
 * @date 2020-12-16 21:02:02
 */
@Mapper
public interface SpuBoundsDao extends BaseMapper<SpuBoundsEntity> {
	
}
