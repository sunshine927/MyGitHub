package com.huayu.hymall.ware.dao;

import com.huayu.hymall.ware.entity.PurchaseEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * 采购信息
 * 
 * @author yuanbao
 * @email 2270830140@qq.com
 * @date 2020-12-16 22:01:40
 */
@Mapper
public interface PurchaseDao extends BaseMapper<PurchaseEntity> {
	
}
