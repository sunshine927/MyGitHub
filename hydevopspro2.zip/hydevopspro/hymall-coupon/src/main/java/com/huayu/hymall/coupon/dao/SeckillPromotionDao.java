package com.huayu.hymall.coupon.dao;

import com.huayu.hymall.coupon.entity.SeckillPromotionEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * 秒杀活动
 * 
 * @author yuanbao
 * @email 2270830140@qq.com
 * @date 2020-12-16 21:02:02
 */
@Mapper
public interface SeckillPromotionDao extends BaseMapper<SeckillPromotionEntity> {
	
}
