package com.huayu.hymall.order.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.huayu.common.utils.PageUtils;
import com.huayu.hymall.order.entity.OrderReturnReasonEntity;

import java.util.Map;

/**
 * 退货原因
 *
 * @author yuanbao
 * @email 2270830140@qq.com
 * @date 2020-12-16 21:50:12
 */
public interface OrderReturnReasonService extends IService<OrderReturnReasonEntity> {

    PageUtils queryPage(Map<String, Object> params);
}

