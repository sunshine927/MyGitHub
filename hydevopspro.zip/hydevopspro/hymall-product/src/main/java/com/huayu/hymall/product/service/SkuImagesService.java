package com.huayu.hymall.product.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.huayu.common.utils.PageUtils;
import com.huayu.hymall.product.entity.SkuImagesEntity;

import java.util.Map;

/**
 * sku图片
 *
 * @author yuanbao
 * @email 2270830140@qq.com
 * @date 2020-12-16 20:48:54
 */
public interface SkuImagesService extends IService<SkuImagesEntity> {

    PageUtils queryPage(Map<String, Object> params);
}

