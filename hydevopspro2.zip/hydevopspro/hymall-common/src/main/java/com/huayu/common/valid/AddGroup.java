package com.huayu.common.valid;

public interface AddGroup {
}
