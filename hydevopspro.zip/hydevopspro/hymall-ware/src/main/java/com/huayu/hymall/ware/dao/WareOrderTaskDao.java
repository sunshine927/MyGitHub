package com.huayu.hymall.ware.dao;

import com.huayu.hymall.ware.entity.WareOrderTaskEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * 库存工作单
 * 
 * @author yuanbao
 * @email 2270830140@qq.com
 * @date 2020-12-16 22:01:40
 */
@Mapper
public interface WareOrderTaskDao extends BaseMapper<WareOrderTaskEntity> {
	
}
