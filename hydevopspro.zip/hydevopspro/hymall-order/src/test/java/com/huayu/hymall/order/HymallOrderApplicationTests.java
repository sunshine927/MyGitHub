package com.huayu.hymall.order;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HymallOrderApplicationTests {

	@Test
	void contextLoads() {
	}

}
