package com.huayu.hymall.product.dao;

import com.huayu.hymall.product.entity.CategoryEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * 商品三级分类
 * 
 * @author yuanbao
 * @email 2270830140@qq.com
 * @date 2020-12-16 20:48:54
 */
@Mapper
public interface CategoryDao extends BaseMapper<CategoryEntity> {
	
}
