package com.huayu.hymall.product.dao;

import com.huayu.hymall.product.entity.SpuImagesEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * spu图片
 * 
 * @author yuanbao
 * @email 2270830140@qq.com
 * @date 2020-12-16 20:48:54
 */
@Mapper
public interface SpuImagesDao extends BaseMapper<SpuImagesEntity> {
	
}
