package com.huayu.hymall.coupon.dao;

import com.huayu.hymall.coupon.entity.HomeSubjectSpuEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * 专题商品
 * 
 * @author yuanbao
 * @email 2270830140@qq.com
 * @date 2020-12-16 21:02:02
 */
@Mapper
public interface HomeSubjectSpuDao extends BaseMapper<HomeSubjectSpuEntity> {
	
}
