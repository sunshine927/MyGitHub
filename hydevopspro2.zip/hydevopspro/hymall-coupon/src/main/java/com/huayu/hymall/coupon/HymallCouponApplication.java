package com.huayu.hymall.coupon;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

@MapperScan("com.huayu.hymall.coupon.dao")
@SpringBootApplication
@EnableDiscoveryClient
public class HymallCouponApplication {

	public static void main(String[] args) {
		SpringApplication.run(HymallCouponApplication.class, args);
	}

}
